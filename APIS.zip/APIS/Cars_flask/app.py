# Previous imports remain...
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask import Flask
from flask import request

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://postgres:028020@localhost:5432/Cars"
db = SQLAlchemy(app)
migrate = Migrate(app, db)

class CarsModel(db.Model):
    __tablename__ = 'cars'

    id = db.Column(db.Integer, primary_key=True)
    names = db.Column(db.String())
    models = db.Column(db.String())
    doors = db.Column(db.Integer())

    def __init__(self, names, models, doors):
        self.names = names
        self.models = models
        self.doors = doors

    def __repr__(self):
        return f"<Car {self.names}>"


@app.route('/cars', methods=['POST', 'GET'])
def handle_cars():
    if request.method == 'POST':
        if request.is_json:
            data = request.get_json()
            new_car = CarsModel(names=data['name'], models=data['model'], doors=data['doors'])
            db.session.add(new_car)
            db.session.commit()
            return {"message": f"car {new_car.names} has been created successfully."}
        else:
            return {"error": "The request payload is not in JSON format"}

    elif request.method == 'GET':
        cars = CarsModel.query.all()
        results = [
            {
                "names": car.names,
                "models": car.models,
                "doors": car.doors
            } for car in cars]

        return {"count": len(results), "cars": results}