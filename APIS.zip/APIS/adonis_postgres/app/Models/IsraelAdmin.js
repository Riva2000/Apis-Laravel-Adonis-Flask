'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class IsraelAdmin extends Model {
}

module.exports = IsraelAdmin
