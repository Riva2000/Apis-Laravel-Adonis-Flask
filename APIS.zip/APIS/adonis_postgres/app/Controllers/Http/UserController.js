'use strict'
const Car = use('App/Models/Car')

class UserController {
    async store({ request,response }) {
          

        const {names,models,doors}=request.only(['names','models','doors'])
        await Car.create({
            names,
            models,
            doors
        })  
        
        return response.status(201).json({names, models, doors})   
    }
    
}

module.exports = UserController
