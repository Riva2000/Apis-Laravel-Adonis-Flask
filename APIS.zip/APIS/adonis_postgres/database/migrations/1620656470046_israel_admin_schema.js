'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class IsraelAdminSchema extends Schema {
  up () {
    this.create('israel_admins', (table) => {
      table.increments()
      table.string('nombre', 80)
      table.string('email',80)
      table.timestamps()
    })
  }

  down () {
    this.drop('israel_admins')
  }
}

module.exports = IsraelAdminSchema
