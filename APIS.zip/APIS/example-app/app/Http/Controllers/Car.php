<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Car as CarModel;

class Car extends Controller
{
    public function Index(Request $request)
    {
        $car= new CarModel([
            'names' => $request->name,
            'models' => $request->model,
            'doors' => $request->doors
        ]);

        $car->save();
        return response()->json(['message' =>'Carro creado con exito'],201);
    }
}
