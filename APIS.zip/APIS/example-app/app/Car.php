<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Car extends Model
{
    protected $fillable = ['names','models','doors'];
    public $timestamps = false;
}
