Primeramente la base de datos que se creara se llama: Cars

Las migraciones se hicieron en el proyecto en flask para ejecutarlas se deberan escribir los siguientes comandos:
flask db init
flask db migrate
flask db upgrade

o puede ser tambien (depende de la version de python instalada)
py -m flask db init
py -m flask db migrate
py -m flask db upgrade

Para los proyectos de Adonis y Laravel apuntan a la misma tabla de postgres.

Adonis (adonis_postgres)
http://127.0.0.1:3333/api/car POST (para insertar un registro nuevo)

Laravel (example_app)
http://127.0.0.1:8000/api/cars POST (para insertar un registro nuevo)

Flask (Cars_flask)
http://127.0.0.1:5000/cars POST 
http://127.0.0.1:5000/cars GET (para ver los registros)

JSON de ejemplo para insertar un dato nuevo
{
	"name":"Ford",
	"model":"Fiesta",
	"doors":4
}
